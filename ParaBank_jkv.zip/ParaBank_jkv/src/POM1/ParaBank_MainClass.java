package POM1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ParaBank_MainClass {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver();
		ParaBank p=new ParaBank();
		Thread.sleep(2000);
		p.MaximizeBrowser(driver);
		p.url(driver);
		p.enterUsername(driver, "Justin");
		Thread.sleep(2000);
		p.enterPassword(driver, "Justin@123");
		Thread.sleep(2000);
		p.loginButton(driver);
		Thread.sleep(2000);
		p.logOutButton(driver);
		Thread.sleep(2000);
		p.closeDriver(driver);
		
		
		
	}

}
