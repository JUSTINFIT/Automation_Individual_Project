package basicProgram;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginandLogout_JOptionPane {
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
//rp
    // URL
		driver.get("https://parabank.parasoft.com/parabank/services.htm");
		//maximize
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		String usn=JOptionPane.showInputDialog("Enter Username");
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Justin");
		Thread.sleep(2000);
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Justin@123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='button']")).click();
		Thread.sleep(2000);
		driver.close();
		
	}//*
}
