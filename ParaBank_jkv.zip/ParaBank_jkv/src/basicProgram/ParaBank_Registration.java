package basicProgram;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ParaBank_Registration {
	WebDriver driver;


	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://parabank.parasoft.com/");

	}


	//aX
	@Test
	public void ParaBank() throws Exception
	{
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div/p[2]/a")).click(); 
		Thread.sleep(2000);
		driver.findElement(By.id("customer.firstName")).sendKeys("Justin");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.lastName")).sendKeys("Varghese");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.street")).sendKeys("Kalamparambil");
		Thread.sleep(2000);
		driver.findElement(By.id("customer.address.city")).sendKeys("Perumbavoor");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.state")).sendKeys("Kerala");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.address.zipCode")).sendKeys("683550");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.phoneNumber")).sendKeys("9072251550");
		Thread.sleep(2000);
        driver.findElement(By.id("customer.ssn")).sendKeys("123456789");
		Thread.sleep(2000);
		driver.findElement(By.id("customer.username")).sendKeys("Justin");
        Thread.sleep(2000);
        driver.findElement(By.id("customer.password")).sendKeys("Justin@123");
        Thread.sleep(2000);
        driver.findElement(By.id("repeatedPassword")).sendKeys("Justin@123");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@value='Register']")).click();
        
		}

	@AfterTest
	public void afterTest() {
		driver.close();
	}

}
