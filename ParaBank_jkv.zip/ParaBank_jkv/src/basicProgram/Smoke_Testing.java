package basicProgram;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Smoke_Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
		
		
		// 1. Open Chrome	
	    WebDriver driver=new ChromeDriver();
	    //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	    driver.manage().deleteAllCookies();
	    
	    
	    
		// 2. Navigate to URL
	    driver.get("https://parabank.parasoft.com/");
	     // 3. Enter Username 
	    WebElement oUserName = driver.findElement(By.name("username"));
	    oUserName.sendKeys("John");
	    
	    // 4. Enter Password
	    WebElement oPassword = driver.findElement(By.name("password"));
	    oPassword.sendKeys("John");
	    
	    //5. Submit xpath
	    WebElement oSubmit = driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/form/div[3]/input"));
	    oSubmit.click();
	    
		String Expected ="ParaBank | Accounts Overview";	
		String actual  = driver.getTitle();
			
		if(Expected.equals(actual)) {
			
			System.out.println("Login Successfull");
		}
		else {
			System.out.println("Login Failed");
		}
			
			


	}

}
