package basicProgram;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPageTitle_Verification {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://parabank.parasoft.com/");
        driver.manage().window().maximize();
        
        
        System.out.println("Page title: "+driver.getTitle());
        
        System.out.println("URL: "+driver.getCurrentUrl());
        
      driver.close();
	}

}
