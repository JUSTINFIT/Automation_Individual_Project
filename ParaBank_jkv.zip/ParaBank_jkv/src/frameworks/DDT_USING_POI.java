package frameworks;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import POM1.ParaBank;
import pom.Parabank;


public class DDT_USING_POI {

	public static void main(String[] args) throws Exception
	{
		FileInputStream file =new FileInputStream("D:\\Automation Testing\\SeleniumProject.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		// JVM will reach to Excel Sheet
		//XSSFWorkbook s=new XSSFWorkbook(file);
		
// Decide unique Excel Sheet
		XSSFSheet s=w.getSheet("DataDriven");
		
		// to Store total no. of row
		int rowsize=s.getLastRowNum();
		System.out.println("No of Credentials: "+rowsize);
		
		//Launch  Browser
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		// Create object of POM Class
		ParaBank p=new ParaBank();

		
		//For Loop
		for(int i=1; i<=rowsize; i++)
		{
			// Store usersname and Password in variables
			String username=s.getRow(i).getCell(0).getStringCellValue();
			String password =s.getRow(1).getCell(1).getStringCellValue();
			
			//Display pair of credential on console
			System.out.println(username+"\t\t"+password);
			
			// Handle Exception(Invalid Credential)
			try {
				// Login Script
				p.url(driver);
				p.MaximizeBrowser(driver);
				Thread.sleep(2000);
				p.enterUsername(driver, username);
				Thread.sleep(2000);
				p.enterPassword(driver, password);
				Thread.sleep(2000);
				p.loginButton(driver);
				Thread.sleep(2000);
				//p.welcomeWindow(driver);
				//Thread.sleep(2000);
				p.logOutButton(driver);
				
				//update TestResult
				
				System.out.println("Valid Credential. ");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Valid Credential.");
				
				
			}
			catch (Exception e)
			{
				System.out.println("Invalid Creadential.");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Invalid Creadential.");
			}
			
			
		}
		
		// write  testResult on Excelsheet
		FileOutputStream out=new FileOutputStream("D:\\Automation Testing\\SeleniumProject.xlsx");
		w.write(out);
		
		//close
		driver.close();


	}

}
