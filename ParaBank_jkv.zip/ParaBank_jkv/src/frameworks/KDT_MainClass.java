package frameworks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class KDT_MainClass {

	public static void main(String[] args)throws Exception
	{
		
     System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
     WebDriver driver = new ChromeDriver();
     driver.manage().window().maximize();
     driver.manage().deleteAllCookies();
     
     //create object  of readExcelClass
     
     ReadExcel1 r = new ReadExcel1();
     r.readExcel(driver);
     
	}

}