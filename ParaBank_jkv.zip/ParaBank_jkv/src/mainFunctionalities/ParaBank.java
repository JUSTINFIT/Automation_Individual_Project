package mainFunctionalities;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.Parabank;

public class ParaBank {
	
	Parabank p=new Parabank();
	
	WebDriver driver;
	
	

	  @BeforeTest
	  public void beforeTest() throws Exception
	  {
		  System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\ParaBank_jkv\\Browser Extension\\chromedriver.exe");
		  driver = new ChromeDriver();
		  Thread.sleep(2000);
		  driver.manage().window().maximize();
		  Thread.sleep(2000);
		  driver.manage().deleteAllCookies();
		  Thread.sleep(2000);
		  p.url(driver);
		  Thread.sleep(2000);
		 p.FirstName(driver, "Justin");
		 Thread.sleep(2000);
		 p.LastName(driver, "Justin@123");
		 Thread.sleep(2000);
		 p.Address(driver);
		 Thread.sleep(2000);
		 p.City(driver);
		 Thread.sleep(2000);
		 p.State(driver);
		 Thread.sleep(2000);
		 p.Zip_Code(driver);
		 Thread.sleep(2000);
		 p.Phone(driver);
		 Thread.sleep(2000);
		 p.SSN(driver);
		 Thread.sleep(2000);
		 p.Username(driver);
		 Thread.sleep(2000);
		 p.Password(driver);
		 Thread.sleep(2000);
		 p.Confirm(driver);
		 Thread.sleep(2000);
		 p.Register(driver);
		  
		  }
	  
	// MainFunctionalities About US

	  @Test(priority =1)
	  public void AboutUS() throws Exception
	  {
		 driver.findElement(By.xpath("//ul[@class='leftmenu']//li//a[@href='about.htm'][normalize-space()='About Us']")).click();
		 Thread.sleep(2000);
		//screenshot
			
			TakesScreenshot ss=(TakesScreenshot) driver;
			// take screenshot
			File src=ss.getScreenshotAs(OutputType.FILE);
			// open file
			File des= new File("./ParaBankFunctionalities.png");
			// save
			FileUtils.copyFileToDirectory(src, des);
			//wait
			Thread.sleep(2000);
			// back to previous page
			driver.navigate().back();
		 
	  }
	  
	  // MainFunctionalities services
	  @Test (priority =2)
	  public void services()throws Exception
	  {
		// click on services	  
			driver.findElement(By.xpath("/html/body/div[2]/div/ul[1]/li[3]/a")).click();
			// wait
			Thread.sleep(2000);
			//screenshot
			
			TakesScreenshot ss=(TakesScreenshot) driver;
			// take screenshot
			File src=ss.getScreenshotAs(OutputType.FILE);
			// open file
			File des= new File("./ParaBankFunctionalities.png");
			// save
			FileUtils.copyFileToDirectory(src, des);
			//wait
			Thread.sleep(2000);
			// back to previous page
			driver.navigate().back();
		  
	  }
	  
	
  @Test(priority =3)
  public void OpenNewAccount() throws Exception
  {
	  driver.findElement(By.xpath("//a[normalize-space()='Open New Account']")).click();
	   Thread.sleep(2000);
	  Select d=new Select(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/select[1]")));
		 d.selectByIndex(1); 
		 Thread.sleep(2000);
		 Select s=new Select(driver.findElement(By.xpath("#fromAccountId")));
		 s.selectByIndex(1); 
		 
		 
		 driver.findElement(By.xpath("//input[@type='submit']")).click();
		 s.selectByIndex(3);
		 Thread.sleep(2000);
		 
		 //ScreenShot 
		 
		 TakesScreenshot ss=(TakesScreenshot) driver;
			File src=ss.getScreenshotAs(OutputType.FILE);
			File des= new File("./ParaBankFuctionalities.png");
			File des1= new File("./ParaBank_Defect.png");
			FileUtils.copyFileToDirectory(src, des);
			FileUtils.copyFileToDirectory(src, des1);
			Thread.sleep(2000);
		 
  }

//main functionalities check home page Online services (AccountOverview)
     @Test(priority =4)  
    public void AccountOverview() {
			 
		 
      driver.findElement(By.xpath("//*[@id=\"leftPanel\"]/ul/li[2]/a")).click();
      
      Select e=new Select(driver.findElement(By.xpath("//select[@id='type']")));
 	 e.selectByIndex(1);
		
 	
    Select f=new Select(driver.findElement(By.xpath("//select[@id='fromAccountId']")));
	 f.selectByIndex(1);
		 
     
     driver.findElement(By.xpath("//input[@value='Open New Account']")).click();
     
    }

     // main functionalities check home page Online services (Transfer Funds)
     @Test (priority = 5)
  public void TransferFunds() throws Exception
     {
    	 driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/ul[2]/li[2]/a")).click();
 		// wait
 		Thread.sleep(2000);
 		// screenshot
 		// create object
 		TakesScreenshot ss=(TakesScreenshot) driver;
 		File src=ss.getScreenshotAs(OutputType.FILE);
 		// new file
 		File des= new File("./ParaBankFunctionalities.png");
 		// new file
 		File des1= new File("./ParaBank_Defect.png");
 		// save location
 		FileUtils.copyFileToDirectory(src, des);
 		// save location
 		FileUtils.copyFileToDirectory(src, des1);
 		// wait
 		Thread.sleep(2000);
 		// back to previous page
 		driver.navigate().back();
  }
  
  
  @AfterTest
  public void afterTest() {
	  driver.close();
  }

}
