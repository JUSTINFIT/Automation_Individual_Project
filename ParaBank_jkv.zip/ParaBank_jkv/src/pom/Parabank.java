package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Parabank {

	
   public void MaximizeBrowser(WebDriver driver)
	{
		driver.manage().window().maximize();
	}
	public void url(WebDriver driver)
	{
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
	}
	public void FirstName(WebDriver driver,String usn)
	{
		driver.findElement(By.id("customer.firstName")).sendKeys(usn);
	}
	public void LastName(WebDriver driver,String pwd)
	{
		driver.findElement(By.id("customer.lastName")).sendKeys(pwd);
	}
	public void Address(WebDriver driver)
	{
		driver.findElement(By.id("customer.address.street")).sendKeys("Kalamparambil");
	}
	
	public void City(WebDriver driver)
	{
		driver.findElement(By.id("customer.address.city")).sendKeys("Perumbavoor");
	}
	
	public void State (WebDriver driver)
	{
		driver.findElement(By.id("customer.address.state")).sendKeys("Kerala");
	}
	
	public void Zip_Code (WebDriver driver)
	{
		 driver.findElement(By.id("customer.address.zipCode")).sendKeys("683550");
	}
	
	public void Phone (WebDriver driver)
	{
		 driver.findElement(By.id("customer.phoneNumber")).sendKeys("9072251550");
	}
	public void SSN (WebDriver driver)
	{
        driver.findElement(By.id("customer.ssn")).sendKeys("123456789");

	}
	public void Username (WebDriver driver)
	{
		driver.findElement(By.id("customer.username")).sendKeys("Justin");

	}
	public void Password (WebDriver driver)
	{
		driver.findElement(By.id("customer.password")).sendKeys("Justin@123");

	}
	public void Confirm (WebDriver driver)
	{
		 driver.findElement(By.id("repeatedPassword")).sendKeys("Justin@123");

	}
	public void  Register(WebDriver driver)
	{
		 driver.findElement(By.xpath("//input[@value='Register']")).click();

	}
	
	/*public void closeDriver(WebDriver driver)
	{
		driver.close();
	}*/

    

}
